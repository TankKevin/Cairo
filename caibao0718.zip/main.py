import os
import sys
import json
import time
import requests
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from tqdm import tqdm
from fake_useragent import UserAgent
from caibao import process_sina

os.chdir(sys.path[0])

start_year = 2022
sheets = {'1-IS': 'lrb', '2-BS': 'fzb', '3-CFS': 'llb'}
tp = '4' # 0：全部，1：一季报，2：半年报，3：三季报，4：年报
page = '1'
num = '10'
agent = UserAgent()

parse = pd.read_excel('input.xlsx')
parse['代码'] = parse['代码'].astype(str).str.zfill(6)
# print(parse)
print('Downloading data from sina.com...')
for i in tqdm(range(parse.shape[0]), total=parse.shape[0]):
    # print(i)
    if not pd.isna(parse.loc[i, '位置']):
        continue
    industry, company, market, code = parse.iloc[i, :4].values
    target = '{}-{}'.format(start_year, company)
    os.makedirs('data', exist_ok=True)
    os.makedirs('output/{}/{}'.format(industry, target), exist_ok=True)
    os.makedirs('output_html/{}'.format(target), exist_ok=True)

    # Download data
    try:
        with pd.ExcelWriter('data/{}.xlsx'.format(target), mode='w', engine='openpyxl') as writer:
            for sheet_name in sheets:
                sheet = sheets[sheet_name]
                url = 'https://quotes.sina.cn/cn/api/openapi.php/CompanyFinanceService.getFinanceReport{start_year}?paperCode={market}{code}&source={sheet}&type={tp}&page={page}&num={num}'.format(**locals())
                result = requests.get(url, headers={'user-agent': agent.random})
                # print(result)
                df = process_sina(json.loads(result.text))
                df.set_index('项目', inplace=True)
                df = df.T
                df.index.name = '时间'
                df.to_excel(writer, sheet_name=sheet_name)
                time.sleep(1)
        location = os.getcwd() + '/output/{}'.format(target)
        parse.loc[i, '位置'] = location
        # print(location)
    except Exception as e:
        print('No data of {} parsed.'.format(target))
        continue

    # Plot data
    section = '1-IS'
    IS = pd.read_excel('data/{}.xlsx'.format(target), sheet_name=section)
    IS['时间'] = IS['时间'].astype(str)
    IS.fillna(0, inplace=True)

    title = 'A营业收入'
    fig = px.area(IS, x='时间', y='营业收入', title=title, text='营业收入')
    fig.update_traces({'texttemplate': '%{y:.2s}', 'textposition':'top center'})
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    IS['营业成本占收入比'] = IS['营业成本'] / IS['营业收入']
    IS['营业税金及附加占比'] = IS['营业税金及附加'] / IS['营业收入']
    IS['销售费用占比'] = IS['销售费用'] / IS['营业收入']
    IS['管理费用占比'] = IS['管理费用'] / IS['营业收入']
    IS['研发费用占比'] = IS['研发费用'] / IS['营业收入']
    IS['营业利润占比*'] = 1 - IS['营业成本	营业税金及附加	销售费用	管理费用	研发费用'.split()].sum(axis=1) / IS['营业收入']
    IS['营业利润占比*'] = IS['营业利润占比*'].map(lambda x: x if x >= 0 else np.nan)

    title = 'B收入成本结构'
    # print(title)
    fig = px.bar(IS, x='时间', y='营业成本占收入比	营业税金及附加占比	销售费用占比	管理费用占比	研发费用占比	营业利润占比*'.split(), 
                title=title + '(*非会计标准)',
                barmode='stack')
    fig.update_layout(yaxis_tickformat='.0%')
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    IS['毛利率'] = 1 - IS['营业成本'] / IS['营业收入']
    IS['销售费用占比'] = IS['销售费用'] / IS['营业收入']
    IS['管理费用占比'] = IS['管理费用'] / IS['营业收入']
    IS['研发费用占比'] = IS['研发费用'] / IS['营业收入']

    title = 'C毛销管研润占收入'
    fig = px.line(IS, x='时间', y='毛利率	销售费用占比	管理费用占比	研发费用占比 营业利润占比*'.split(), 
                  title=title,)
    fig.update_traces(patch={'text': IS['毛利率']}, selector={'name': '毛利率'})
    fig.update_traces(patch={'text': IS['销售费用占比']}, selector={'name': '销售费用占比'})
    fig.update_traces(patch={'text': IS['管理费用占比']}, selector={'name': '管理费用占比'})
    fig.update_traces(patch={'text': IS['研发费用占比']}, selector={'name': '研发费用占比'})
    fig.update_traces(patch={'text': IS['营业利润占比*']}, selector={'name': '营业利润占比*'})
    fig.update_traces({'mode': 'markers+lines+text', 'texttemplate': '%{y:.2%}', 'textposition':'top center'})
    fig.update_layout(yaxis_tickformat='.0%')
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    section = '2-BS'
    BS = pd.read_excel('data/{}.xlsx'.format(target), sheet_name=section)
    BS['时间'] = BS['时间'].astype(str)
    BS.fillna(0, inplace=True)

    title = 'A总资产'
    fig = px.area(BS, x='时间', y='资产总计', title=title, text='资产总计')
    fig.update_traces({'texttemplate': '%{y:.2s}', 'textposition':'top center'})
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    BS['货币资金等'] = BS['货币资金 拆出资金 交易性金融资产'.split()].sum(axis=1)
    BS['应收账款等'] = BS['应收账款 应收票据 应收款项融资 合同资产'.split()].sum(axis=1)

    title = 'B资产明细堆积图'
    fig = px.area(BS, x='时间', y='货币资金等	应收账款等	预付款项	存货	其他流动资产	长期股权投资	商誉 	固定资产及清理合计	在建工程合计	使用权资产	无形资产	其他非流动资产'.split(), title=title)
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    BS['资产负债率'] = BS['负债合计'] / BS['资产总计']
    BS['扣除预收款项后负债率'] = (BS['负债合计'] - BS['预收款项']) / BS['资产总计']
    BS['有息负债'] = BS['吸收存款及同业存放 短期借款 长期借款 应付债券 一年内到期的非流动负债'.split()].sum(axis=1)
    BS['有息负债率'] = (BS['吸收存款及同业存放 短期借款 长期借款 应付债券 一年内到期的非流动负债'.split()].sum(axis=1)) / BS['资产总计']

    title = 'C资产负债率'
    fig = px.bar(BS, x='时间', y='资产负债率 扣除预收款项后负债率 有息负债率'.split(), 
                title=title,
                barmode='group')
    fig.update_traces(patch={'text': BS['资产负债率'], 'texttemplate': '%{y:.0%}'}, selector={'name': '资产负债率'})
    fig.update_traces(patch={'text': BS['扣除预收款项后负债率'], 'texttemplate': '%{y:.0%}'}, selector={'name': '扣除预收款项后负债率'})
    fig.update_traces(patch={'text': BS['有息负债率'], 'texttemplate': '%{y:.0%}'}, selector={'name': '有息负债率'})
    fig.update_traces({'textposition':'outside'})
    fig.update_layout(yaxis_tickformat='.0%')
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    BS['应付账款等'] = BS['应付票据 应付账款'.split()].sum(axis=1)
    BS['预收款项等'] = BS['预收款项 合同负债'.split()].sum(axis=1)
    BS['应付职工薪酬等'] = BS['应付职工薪酬 长期应付职工薪酬'.split()].sum(axis=1)

    title = 'D负债明细堆积图'
    fig = px.area(BS, x='时间', y='有息负债	应付账款等	预收款项等	应付职工薪酬等 	应交税费	其他应付款合计	其他流动负债 租赁负债	长期应付款合计	其他非流动负债'.split(), title=title)
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    section = '3-CFS'
    CFS = pd.read_excel('data/{}.xlsx'.format(target), sheet_name=section)
    CFS['时间'] = CFS['时间'].astype(str)
    CFS.fillna(0, inplace=True)

    title = 'A三类现金流量净额'
    fig = px.bar(CFS, x='时间', y='经营活动产生的现金流量净额 筹资活动产生的现金流量净额	投资活动产生的现金流量净额'.split(), 
                title=title,
                barmode='group')
    fig.update_traces(patch={'text': CFS['经营活动产生的现金流量净额'], 'texttemplate': '%{y:.2s}'}, selector={'name': '经营活动产生的现金流量净额'})
    fig.update_traces(patch={'text': CFS['筹资活动产生的现金流量净额'], 'texttemplate': '%{y:.2s}'}, selector={'name': '筹资活动产生的现金流量净额'})
    fig.update_traces(patch={'text': CFS['投资活动产生的现金流量净额'], 'texttemplate': '%{y:.2s}'}, selector={'name': '投资活动产生的现金流量净额'})
    fig.update_traces({'textposition':'outside'})
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    section = '4-DP'
    DP = IS.iloc[:, :1].copy()
    DP['净资产收益率'] = IS['净利润_大类'] / ((BS['所有者权益(或股东权益)合计'] + BS['所有者权益(或股东权益)合计'].shift()) / 2)
    DP['销售净利率*'] = IS['净利润_大类'] / IS['营业收入']
    DP['总资产周转率'] = IS['营业收入'] / ((BS['资产总计'] + BS['资产总计'].shift()) / 2)
    DP['权益乘数'] = ((BS['资产总计'] + BS['资产总计'].shift()) / 2) / ((BS['所有者权益(或股东权益)合计'] + BS['所有者权益(或股东权益)合计'].shift()) / 2)
    DP['应收账款周转率'] = IS['营业收入'] / ((BS['应收账款'] + BS['应收账款'].shift()) / 2)
    DP['固定资产周转率'] = IS['营业收入'] / ((BS['固定资产及清理合计'] + BS['固定资产及清理合计'].shift()) / 2)
    DP['应付账款周转率'] = IS['营业成本'] / ((BS['应付账款'] + BS['应付账款'].shift()) / 2)
    DP['存货周转率'] = IS['营业成本'] / ((BS['存货'] + BS['存货'].shift()) / 2)
    DP = DP.iloc[1:, :]
    for rate in '应收账款周转率 固定资产周转率	应付账款周转率	存货周转率'.split():
        DP[rate] = DP[rate].map(lambda x: x if x < 20 else np.nan)


    title = 'A净资产收益率'
    fig = px.area(DP, x='时间', y='净资产收益率', title=title, text='净资产收益率')
    fig.update_traces({'texttemplate': '%{y:.2%}', 'textposition':'top center'})
    fig.update_layout(yaxis_tickformat='.0%')
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    title = 'B净资产收益率拆分(*销售净利率用净利润率替代)'
    fig = px.line(DP, x='时间', y='销售净利率* 总资产周转率	权益乘数'.split(), 
                  title=title)
    fig.update_traces(patch={'text': DP['销售净利率*'], 'texttemplate': '%{y:.2f}'}, selector={'name': '销售净利率*'})
    fig.update_traces(patch={'text': DP['总资产周转率'], 'texttemplate': '%{y:.2f}'}, selector={'name': '总资产周转率'})
    fig.update_traces(patch={'text': DP['权益乘数'], 'yaxis': 'y2', 'texttemplate': '%{y:.2f}'}, selector={'name': '权益乘数'})
    fig.update_traces({'mode': 'markers+lines+text', 'textposition':'top center'})
    fig.update_layout(
        yaxis={'title': '销售净利率*/总资产周转率', },
        yaxis2={'title': '权益乘数', 'overlaying': 'y', 'side': 'right'},
        title=title
    )
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

    title = 'C主要资产周转率'
    fig = px.line(DP, x='时间', y='应收账款周转率 固定资产周转率	应付账款周转率	存货周转率'.split(), 
                  title=title + '(收入-应收账款、固定资产 成本-应付账款、存货，大于 20 不显示)')
    fig.update_traces(patch={'text': DP['应收账款周转率']}, selector={'name': '应收账款周转率'})
    fig.update_traces(patch={'text': DP['固定资产周转率']}, selector={'name': '固定资产周转率'})
    fig.update_traces(patch={'text': DP['应付账款周转率']}, selector={'name': '应付账款周转率'})
    fig.update_traces(patch={'text': DP['存货周转率']}, selector={'name': '存货周转率'})
    fig.update_traces({'mode': 'markers+lines+text', 'texttemplate': '%{y:.2f}', 'textposition':'top center'})
    fig.write_image('output/{}/{}/{}-{}-{}.png'.format(industry, target, company, section, title), scale=1.5)
    fig.write_html('output_html/{}-{}-{}.html'.format(company, section, title))

parse.to_excel('input.xlsx', index=False)